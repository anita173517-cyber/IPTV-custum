package com.harindra.iptvpro

import okhttp3.ConnectionPool
import okhttp3.Dispatcher
import okhttp3.Dns
import okhttp3.OkHttpClient
import okhttp3.Protocol
import java.net.InetAddress
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.TimeUnit

/**
 * Upgrade 9: Persistent Connection Pool, TCP Keep-Alive & Bounded In-Memory DNS Cache.
 * Preserves isolated metadataDispatcher, apiDispatcher, and streamDispatcher so background
 * requests never starve live HLS/DASH segment fetches on 512 MB RAM Android TVs.
 */
object NetworkClient {
    private const val DNS_TTL_MS = 30L * 60L * 1000L // 30-minute TTL
    private const val MAX_DNS_ENTRIES = 50

    private data class DnsEntry(
        val addresses: List<InetAddress>,
        val timestampMs: Long
    )

    private val dnsCache = ConcurrentHashMap<String, DnsEntry>(64)

    /**
     * Bounded thread-safe in-memory DNS cache (max 50 hosts, 30-min TTL)
     * so random channel switches on the same IPTV host require 0ms DNS lookup.
     */
    val quantumDns: Dns = object : Dns {
        override fun lookup(hostname: String): List<InetAddress> {
            val key = hostname.lowercase()
            val now = System.currentTimeMillis()
            val cached = dnsCache[key]
            if (cached != null && (now - cached.timestampMs) < DNS_TTL_MS && cached.addresses.isNotEmpty()) {
                return cached.addresses
            }
            val resolved = Dns.SYSTEM.lookup(hostname)
            if (resolved.isNotEmpty()) {
                if (dnsCache.size >= MAX_DNS_ENTRIES) {
                    val oldestKey = dnsCache.entries.minByOrNull { it.value.timestampMs }?.key
                    if (oldestKey != null) dnsCache.remove(oldestKey)
                }
                dnsCache[key] = DnsEntry(resolved, now)
            }
            return resolved
        }
    }

    private fun dispatcher(max: Int, perHost: Int) = Dispatcher().apply {
        maxRequests = max
        maxRequestsPerHost = perHost
    }

    private fun pool(maxIdle: Int) = ConnectionPool(maxIdle, 5, TimeUnit.MINUTES)

    private val metadataDispatcher by lazy { dispatcher(max = 5, perHost = 3) }
    private val apiDispatcher by lazy { dispatcher(max = 5, perHost = 3) }
    private val streamDispatcher by lazy { dispatcher(max = 10, perHost = 5) }

    private val metadataPool by lazy { pool(maxIdle = 4) }
    private val apiPool by lazy { pool(maxIdle = 4) }
    private val streamPool by lazy { pool(maxIdle = 6) }

    /** Short, bounded calls for connection checks, pre-fetch warmup and lightweight metadata. */
    val fastMetaClient: OkHttpClient by lazy {
        OkHttpClient.Builder()
            .dns(quantumDns)
            .protocols(listOf(Protocol.HTTP_2, Protocol.HTTP_1_1))
            .connectionPool(metadataPool)
            .dispatcher(metadataDispatcher)
            .connectTimeout(4, TimeUnit.SECONDS)
            .readTimeout(10, TimeUnit.SECONDS)
            .writeTimeout(8, TimeUnit.SECONDS)
            .retryOnConnectionFailure(true)
            .followRedirects(true)
            .followSslRedirects(true)
            .build()
    }

    /** Longer timeouts for M3U, Xtream and XMLTV responses. */
    val apiClient: OkHttpClient by lazy {
        OkHttpClient.Builder()
            .dns(quantumDns)
            .protocols(listOf(Protocol.HTTP_2, Protocol.HTTP_1_1))
            .connectionPool(apiPool)
            .dispatcher(apiDispatcher)
            .connectTimeout(8, TimeUnit.SECONDS)
            .readTimeout(45, TimeUnit.SECONDS)
            .writeTimeout(15, TimeUnit.SECONDS)
            .retryOnConnectionFailure(true)
            .followRedirects(true)
            .followSslRedirects(true)
            .build()
    }

    /** Dedicated live-stream dispatcher with 0ms cached DNS & 5-min keep-alive pool. */
    val streamClient: OkHttpClient by lazy {
        OkHttpClient.Builder()
            .dns(quantumDns)
            .protocols(listOf(Protocol.HTTP_2, Protocol.HTTP_1_1))
            .connectionPool(streamPool)
            .dispatcher(streamDispatcher)
            .connectTimeout(4, TimeUnit.SECONDS)
            // 20s is still bounded while tolerating brief Wi-Fi jitter on live segments.
            .readTimeout(20, TimeUnit.SECONDS)
            .writeTimeout(10, TimeUnit.SECONDS)
            .retryOnConnectionFailure(true)
            .followRedirects(true)
            .followSslRedirects(true)
            .build()
    }
}
