package com.harindra.iptvpro

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class M3uParserTest {
    @Test
    fun parsesMetadataAndChannelUrl() {
        val playlist = """#EXTM3U
#EXTINF:-1 tvg-id="news.in" tvg-logo="https://cdn.example/logo.png" group-title="News",India News HD
https://stream.example/news/index.m3u8
""".trimIndent()

        val channels = M3uParser.parse(playlist)
        assertEquals(1, channels.size)
        assertEquals("India News HD", channels[0].name)
        assertEquals("News", channels[0].category)
        assertEquals("news.in", channels[0].epgId)
        assertEquals("https://cdn.example/logo.png", channels[0].logoUrl)
        assertEquals("https://stream.example/news/index.m3u8", channels[0].streamUrl)
    }

    @Test
    fun removesUtf8BomAndDeduplicatesIdenticalStreamUrls() {
        val playlist = "\uFEFF" + """#EXTM3U
#EXTINF:-1,First
https://stream.example/live.m3u8
#EXTINF:-1,Duplicate
https://stream.example/live.m3u8
"""
        val channels = M3uParser.parse(playlist)
        assertEquals(1, channels.size)
        assertEquals("First", channels.first().name)
    }

    @Test
    fun supportsReaderInputAndChannelLimit() {
        val playlist = """#EXTM3U
#EXTINF:-1,One
https://stream.example/1.m3u8
#EXTINF:-1,Two
https://stream.example/2.m3u8
"""
        val channels = M3uParser.parse(playlist.reader(), maxChannels = 1)
        assertEquals(1, channels.size)
        assertTrue(channels.first().number == 1)
    }

    @Test
    fun attachesSecondDistinctStreamUrlAsBackupUrlForSameChannelName() {
        val playlist = """#EXTM3U
#EXTINF:-1 group-title="Sports",Sports 18 HD
https://stream.example/primary.m3u8
#EXTINF:-1 group-title="Sports",Sports 18 HD
https://stream.example/backup.m3u8
"""
        val channels = M3uParser.parse(playlist)
        assertEquals(1, channels.size)
        assertEquals("https://stream.example/primary.m3u8", channels[0].streamUrl)
        assertEquals("https://stream.example/backup.m3u8", channels[0].backupUrl)
    }
}
